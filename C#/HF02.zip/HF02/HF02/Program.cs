﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HF02
{
    internal class Program
    {
        static bool Parose(int a)
        {
            if (a % 2 == 0)
            {
                return true;
            }

            else
            {
                return false;
            }
        }

        static bool Novekvo(int a, int b, int c)
        {
            if (a < b && a < c && b < c)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        static bool Csokkeno(int a, int b, int c)
        {
            if (a > b && a > c && b > c)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static double Negyzet(double a)
        {
            return a * a;
        }
        static int Osszead(int a, int b)
        {
            return a + b;
        }

        static double PontTavolsag(int x1, int y1, int x2, int y2)
        {

            return Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
        }


        static void Main(string[] args)
        {
            Console.WriteLine($"1.feladat: {Parose(3)}");
            Console.WriteLine($"2.feladat: {Novekvo(4,3,2)}");
            Console.WriteLine($"3.feladat: {Csokkeno(3,2,1)}");
            Console.WriteLine($"4.feladat: {Negyzet(6)}");
            Console.WriteLine($"5.feladat: {Osszead(6,6)}");
            Console.WriteLine($"6.feladat: {PontTavolsag(6,3,5,8)}");

        }
    }
}
