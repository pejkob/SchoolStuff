﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kor
{
    internal class Program
    {
        /// <summary>
        /// Kör kerületének kiszámítása
        /// </summary>
        /// <param name="d">Kör átmérője</param>
        /// <returns>Kör kerülete</returns>
        static double KorKerulete(double d)
        {
            return Math.Round(d * Math.PI,2);
        }
        /// <summary>
        /// Kör területének kiszámítása
        /// </summary>
        /// <param name="d">Kör átmérője</param>
        /// <returns>Kör területe</returns>
        static double KorTerulete(double d)
        {
            return Math.Round( Math.Pow(d/2,2) * Math.PI,2);
        }
        static void Main(string[] args)
        {
            Console.Write("Kérem adja meg a kör átmérőjét! ");
            double d=double.Parse(Console.ReadLine());

            Console.WriteLine($"Kör kerülete: {KorKerulete(d)}");
            Console.WriteLine($"Kör területe: {KorTerulete(d)}");
            Console.ReadKey();

        }

        
    }
}
