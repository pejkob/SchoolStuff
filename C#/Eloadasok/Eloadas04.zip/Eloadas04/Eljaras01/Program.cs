﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eljaras01
{
    internal class Program
    {

        static void TeglalapTerulete1()
        {

            Console.WriteLine("Kérem, a téglalap A oldalát! ");
            double a = double.Parse(Console.ReadLine());

            Console.WriteLine("Kérem, a téglalap B oldalát! ");
            double b = double.Parse(Console.ReadLine());

            Console.WriteLine($"A téglalap területe: {a * b}m^2");
        }

        static double TeglalapTerulete2(double a,double b)
        {
            return a * b;
        }


        static void Main(string[] args)
        {
            TeglalapTerulete1();
            Console.WriteLine("Kérem, a téglalap A oldalát! ");
            double a = double.Parse(Console.ReadLine());

            Console.WriteLine("Kérem, a téglalap B oldalát! ");
            double b = double.Parse(Console.ReadLine());

            
            Console.WriteLine($"A téglalap területe: {TeglalapTerulete2(a, b)}m^2"); 
            Console.ReadKey();

        }
    }
}
