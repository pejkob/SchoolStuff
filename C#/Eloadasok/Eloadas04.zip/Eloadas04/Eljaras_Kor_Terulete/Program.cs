﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eljaras_Kor_Terulete
{
    internal class Program
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sugar"></param>
        /// <returns></returns>
        static double KorTerulet1(double sugar)
        {
            return Math.Round( Math.Pow(sugar,2)* Math.PI,2);
        }
        static void KorTerulet2()
        {
            Console.WriteLine("Kérem, adja meg a kör sugarát! ");
            double sugar = double.Parse(Console.ReadLine());

            Console.WriteLine($"A kör területe: {Math.Round((sugar*sugar)*Math.PI,2)}");
        }
        /// <summary>
        /// Derékszögű háromszög vizsgálat adatbekérés nélkül
        /// </summary>
        /// <param name="a">a oldal értéke</param>
        /// <param name="b">b oldal értéke</param>
        /// <param name="c">c oldal értéke</param>
        static void DerekszoguHaromszog1(double a,double b ,double c)
        {
           if (a * a + b * b == c * c)
            {
                Console.WriteLine("A háromszög derékszögű");
            }
            else
            {
                Console.WriteLine("A háromszög nem derékszögű");
            }
        }
        static void DerekszoguHaromszog2()
        {
            Console.WriteLine("Kérem adja meg a háromszög egyik oldalát!");
            double a = double.Parse(Console.ReadLine());
            Console.WriteLine("Kérem adja meg a háromszög másik oldalát!");
            double b = double.Parse(Console.ReadLine());
            Console.WriteLine("Kérem adja meg a háromszög harmadik oldalát!");
            double c = double.Parse(Console.ReadLine());

            if (a*a+b*b==c*c)
            {
                Console.WriteLine("A háromszög derékszögű");
            }
            else
            {
                Console.WriteLine("A háromszög nem derékszögű");
            }
        }

        static void Main(string[] args)
        {
            KorTerulet2();
            Console.WriteLine("Kérem, adja meg a kör sugarát! ");
            double sugar=double.Parse(Console.ReadLine());

            Console.WriteLine($"A kör területe: {KorTerulet1(sugar)}");
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("Kérem adja meg a háromszög egyik oldalát!");
            double a=double.Parse(Console.ReadLine());
            Console.WriteLine("Kérem adja meg a háromszög másik oldalát!");
            double b = double.Parse(Console.ReadLine());
            Console.WriteLine("Kérem adja meg a háromszög harmadik oldalát!");
            double c=double.Parse(Console.ReadLine());
            DerekszoguHaromszog1(a,b,c);
            Console.WriteLine();
            DerekszoguHaromszog2();

            Console.ReadKey();

        }

        
    }
}
