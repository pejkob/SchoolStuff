﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeglalapFugveny
{
    internal class Program
    {
        /// <summary>
        /// Téglalap területének kiszámítása
        /// </summary>
        /// <param name="a">téglalap a oldala</param>
        /// <param name="b">téglalap b oldala</param>
        /// <returns>Téglalap területe</returns>
        static double TeglalapTerulete(double a, double b)
        {
            return a * b;
        }
        /// <summary>
        /// Téglalap területének kiszámítása
        /// </summary>
        /// <param name="a">téglalap a oldala</param>
        /// <param name="b">téglalap b oldala</param>
        /// <returns>Téglalap kerülete</returns>

        static double TeglalapKerulete(double a, double b)
        {
            return 2 * (a + b);
        }
        /// <summary>
        /// Téglalap átló kiszámítás
        /// </summary>
        /// <param name="a">téglalap a oldala</param>
        /// <param name="b">téglalap b oldala</param>
        /// <returns>Téglalap átlója</returns>
        static double TeglalapAtloja(double a, double b)
        {
            return Math.Sqrt(a*a+b*b);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Kérem, a téglalap A oldalát! ");
            double a = double.Parse(Console.ReadLine());

            Console.WriteLine("Kérem, a téglalap B oldalát! ");
            double b = double.Parse(Console.ReadLine());
            Console.WriteLine($"A téglalap területe:{TeglalapTerulete(a,b)}");
            Console.WriteLine($"A téglalap kerülete:{TeglalapKerulete(a, b)}");
            Console.WriteLine($"A téglalap átlója:{TeglalapAtloja(a, b)}");
            // Console.WriteLine($"A téglalap területe: {a*b}");
            Console.ReadKey();
        }
    }
}
