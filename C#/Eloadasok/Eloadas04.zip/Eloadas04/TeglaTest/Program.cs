﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeglaTest
{
    internal class Program
    {
        /// <summary>
        /// Téglatest Felületének a kiszámítása paraméterek nélkül
        /// </summary>
        static void TeglaTestFelulete()
        {
            Console.Write("Kérem az A oldal méretét: ");
            int a=int.Parse(Console.ReadLine());
            Console.Write("Kérem a B oldal méretét: ");
            int b=int.Parse(Console.ReadLine());
            Console.Write("Kérem a C oldal méretét: ");
            int c=int.Parse(Console.ReadLine());
            Console.WriteLine($"A téglatest felszíne: {2*(a*b+a*c+b*c)}");
        }

        /// <summary>
        /// Téglatest Felületének a kiszámítása paraméterekkel
        /// </summary>
        /// <param name="a">a-szélesség</param>
        /// <param name="b">b-magasság</param>
        /// <param name="c">c-hosszúság</param>
        static void TeglaTestFelulete(int a,int b,int c)
        {
           
            Console.WriteLine($"A téglatest felszíne: {2 * (a * b + a * c + b * c)}");
        }

        static void Main(string[] args)
        {
            TeglaTestFelulete();
            TeglaTestFelulete(12,6,25);
            Console.ReadKey();



        }
    }
}
